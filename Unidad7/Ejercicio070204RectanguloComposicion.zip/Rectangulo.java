/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author user
 */
import java.lang.Math;
public class Rectangulo {

    Punto vertice1;
    Punto vertice2;

    public Rectangulo(Punto vertice1, Punto vertice2) {
        this.vertice1 = new Punto(vertice1);
        this.vertice2 = new Punto(vertice2);
    }

    public String toString() {
        String retorno = "Rectangulo con los puntos Q: (" + vertice1 + ") y R: ( " + vertice2 + ")" + "\n" + "altura: " + calcularAltura() + " base: " + calcularBase() ;
        return retorno;
    }

    public double calcularAltura(){
        double altura = vertice1.getY() - vertice2.getY();
            
        return altura;
    }
    public double calcularBase(){
        double base = vertice1.getX() - vertice2.getX();
            
        return base;
    }
}


