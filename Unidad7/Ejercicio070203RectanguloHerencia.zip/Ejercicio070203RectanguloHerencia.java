/**
 *
 * @author ()
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // objeto de la clase rectangulo
        rectangulo rectangulo1 = new rectangulo(4.5,6.5,5,6);

        System.out.print(rectangulo1.toString());
    }

}
