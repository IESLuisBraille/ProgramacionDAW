/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
//clase rectangulo que hereda de la clase punto
public class rectangulo extends Punto {
//atributos de ciculo    
	private double ancho;
	private double largo;
//constructor de rectangulo
	public rectangulo(double ancho, double largo, double ParamX, double ParamY) {
		super(ParamX, ParamY);
		this.ancho = ancho;
		this.largo = largo;
	}
	
	public rectangulo( Punto origen, double ancho, double alto){
		super(origen);
		this.ancho = ancho;
		this.largo = largo;
	}
//getters y setters de rectangulo
	public double getAncho() {
		return ancho;
	}

	public void setAncho(double ancho) {
			this.ancho = ancho;
	}

	public double getLargo() {
		return largo;
	}

	public void setLargo(double largo) {
		this.largo = largo;
	}
//toString de rectangulo
	@Override
	public String toString() {
		return "rectangulo" + " ancho=" + ancho + ", largo=" + largo +
						"\n" + "Punto" + "(" + getX() + "," + getY() + ")";
	}
}
