/**
 * Punto
 * @author ()
 */
public class Punto {
//atributos de Punto
    private double x;
    private double y;
//getter y setter de Punto
    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }
//constructor de Punto
    public Punto(double ParamX, double ParamY) {
        x = ParamX;
        y = ParamY;
    }
    public Punto( Punto p ){
        x = p.getX();
        y = p.getY();
    }
}
